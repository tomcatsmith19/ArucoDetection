function subject_list = Vulintus_Load_Previous_Subjects(sys_name,config_path,varargin)

%
%Vulintus_Load_Previous_Subjects.m - Vulintus, Inc.
%
%   VULINTUS_LOAD_PREVIOUS_SUBJECTS is a Vulintus behavior program toolbox
%   function that loads the list of previous subjects run on the specified
%   Vulintus system ("sys_name") from the specified directory
%   ("config_path").
%   
%   UPDATE LOG:
%   11/29/2021 - Drew Sloan - Function first created.
%

if ~any(strcmpi(sys_name,...
        {'mototrak','omnitrak','sensitrak','habitrak','omnihome'}))         %If the specified system name doesn't match any Vulintus system...
    error(['ERROR IN VULINTUS_LOAD_PREVIOUS_SUBJECTS: Specified system '...
        '"%" isn''t a recognized Vulintus sytem!'],sys_name);               %Throw an error.
end

subject_file = fullfile(config_path,...
    [lower(sys_name) '_subject_list.txt']);                                 %Set the expected filename of the configuration file.
placeholder = fullfile(config_path,...
    [lower(sys_name) '_subject_list_placeholder.temp']);                    %Set the filename for the temporary placeholder file.

if ~exist(subject_file,'file')                                              %If no subject file exists...
    subject_list = {};                                                      %Return empty brackets.
    return                                                                  %Skip execution of the rest of the function.
end

if exist(placeholder,'file')                                                %If the placeholder file exists...
    temp = dir(placeholder);                                                %Grab the file information for the placeholder file.
    while exist(placeholder,'file') && now - temp.datenum < 1/86400         %Loop until the placeholder is deleted or until 1 second has passed.
        pause(0.1);                                                         %Pause for 100 milliseconds.
    end
    if exist(placeholder,'file')                                            %If the placeholder still exists...
        delete(placeholder);                                                %Delete the placeholder file.
    end
end

subject_list = Vulintus_Read_TSV_File(subject_file);                        %Read in the subject list from the TSV-formated file.

if nargin > 2 && ishandle(varargin{1})                                      %If a dropdown menu handle was provided... 
    subject_list(end + (1:2)) = ...
        {'<Add New Subject>';'<Edit Subject List>'};                        %Add options for adding a new subject or editing the list.
    varargin{1}.Items = subject_list;                                       %Update the subject drop-down items.
    varargin{1}.Value = subject_list{1};                                    %Set the initially selected subject to the first value.
end