function subject = Vulintus_Behavior_Select_Subject(dropdown,~,sys_name)           

%
%Vulintus_Behavior_Select_Subject.m - Vulintus, Inc.
%
%   VULINTUS_BEHAVIOR_SELECT_SUBJECT executes when the user selects a
%   subject from the subject drop-down menu.
%   
%   UPDATE LOG:
%   11/29/2021 - Drew Sloan - Function first created, adapted from
%       Vibrotactile_Detection_Task_Edit_Rat.m
%   12/02/2021 - Drew Sloan - Converted the function to a toolbox function.
%

global run                                                                  %Initialize the global run variable.

subject = dropdown.Value;                                                   %Grab the selected subject.
if any(strcmpi(subject,{'<add new subject>','<edit subject list>'}))        %If the user wants to edit the subject list or add a new subject name...
    Vulintus_Behavior_Edit_Subjects(dropdown,sys_name);                     %Call the toolbox function to edit the subject list.
else                                                                        %Otherwise, if the user selected an existing subject...
    handles = guidata(gcbf );                                               %Grab the handles structure from the main GUI.
    handles.subject = upper(subject);                                       %Save the subject in the handles menu.
    guidata(gcbf,handles);                                                  %Save the handles.structure back to the GUI.
    run = 1.6;                                                              %Set the global run variable to 1.6.
end