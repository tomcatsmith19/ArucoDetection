function Vulintus_Behavior_Manual_Feed(fid, blk_code, ardy, feeder_index, varargin)

%
%Vulintus_Behavior_Manual_Feed.m - Vulintus, Inc.
%
%   VULINTUS_BEHAVIOR_MANUAL_FEED triggers a manual feeding through the
%   specified system and writes the timing data to the *.OmniTrak data file
%   specified with the "fid" file identifier.
%   
%   UPDATE LOG:
%   01/24/2020 - Drew Sloan - Function first implemented as 
%       Vibrotactile_Detection_Task_Manual_Feed.m.
%   12/10/2021 - Drew Sloan - Converted the function to a toolbox function.
%

if ~isfield(ardy,'system')                                                  %If the serial function structure doesn't contain a system name...
    ardy.system = 'MotoTrak';                                               %Assume that the system is MotoTrak.
end
    
switch lower(ardy.system)                                                   %Switch between the recognized Vulintus systems.
    
    case 'mototrak'                                                         %If this is a MotoTrak system.
        handles.ardy.feed();                                                %Trigger a feeding through the MotoTrak controller.

end

%Write the feeding time to file.
fwrite(fid, blk_code, 'uint16');                                            %Write the software manual feed block code to the file.
fwrite(fid, feeder_index, 'uint8');                                         %Write the dispenser index to the file.
fwrite(fid, now, 'float64');                                                %Write the serial date number to the file as a 64-bit floating point.
fwrite(fid, 1, 'uint16');                                                   %Write the number of feedings to the file.

%Print a message to the messagebox.
if nargin > 4 && ishandle(varargin{4})                                      %If the user passed a messagebox handle...
    str = sprintf('%s - Manual Feeding',datestr(now,13));                   %Create a message string.
    if nargin > 5 && isnumeric(varargin{5})                                 %If the user passed a feed count...
        str = horzcat(str,sprintf(', %1.0f feedings', varargin{5}));        %Add the feed count to the message.
    end
    Add_Msg(handles.msgbox, str);                                           %Show the message in the message box.
end