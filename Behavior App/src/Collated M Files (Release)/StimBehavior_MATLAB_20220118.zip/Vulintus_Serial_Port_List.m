function port_list = Vulintus_Serial_Port_List

%Vulintus_Serial_Port_List.m - Vulintus, Inc.
%
%   VULINTUS_SERIAL_PORT_LIST finds all connected serial port devices and
%   pairs the assigned COM port with device descriptions stored in the
%   system registry.
%
%   UPDATE LOG:
%   11/29/2021 - Drew Sloan - Function first created.
%

ports = serialportlist('all');                                              %Grab all serial ports.
if isempty(ports)                                                           %If no serial ports were found...
    port_list = {};                                                         %Set the function output to empty.
    return                                                                  %Skip execution of the rest of the function.
end
port_list = cell(numel(ports),3);                                           %Create an N-by-3 cell array to hold port info.

busyports = serialportlist('available');                                    %Find all ports that are currently available.
for i = 1:numel(ports)                                                      %Step through each port.
    port_list{i,1} = ports{i};                                              %Copy the port name to the first column of the list.
    if any(strcmpi(port_list{i,1},busyports))                               %If the serial port is available...
        port_list{i,2} = 'available';                                       %List the port as available.
    else                                                                    %Otherwise...
        port_list{i,2} = 'busy';                                            %List the port as busy.
    end
end

key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\USB\';              %Set the registry query field.
[~, txt] = dos(['REG QUERY ' key ' /s /f "FriendlyName" /t "REG_SZ"']);     %Query the registry for all USB devices.
for i = 1:size(port_list,1)                                                 %Step through each port.
    j = strfind(txt,['(' ports{i} ')']);                                    %Find the port in the USB device list.    
    if ~isempty(j)                                                          %If a matching port was found...
        k = strfind(txt(1:j(end)),'REG_SZ');                                %Find the REG_SZ preceding the prot description.
        if any(k)                                                           %If the REG_SZ was found...
            port_list{i,3} = strtrim(txt(k(end)+7:j(end)-1));               %Grab the port description.
        end
    end
end