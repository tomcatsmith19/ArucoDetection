function Vulintus_Behavior_Edit_Subjects(dropdown,sys_name)      

%
%Vulintus_Behavior_Edit_Subjects.m - Vulintus, Inc.
%
%   VULINTUS_BEHAVIOR_EDIT_SUBJECTS is a Vulintus behavioral program 
%   toolbox function which creates a dialog box for users to edit the 
%   current subject list and to add new subject names.
%
%   
%   UPDATE LOG:
%   12/02/2021 - Drew Sloan - Function first created
%

fprintf(1,'Need to finish coding: %s\n',mfilename);